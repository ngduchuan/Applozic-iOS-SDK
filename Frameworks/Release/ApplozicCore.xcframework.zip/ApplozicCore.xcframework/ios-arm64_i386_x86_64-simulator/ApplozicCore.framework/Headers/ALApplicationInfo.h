//
//  ALApplicationInfo.h
//  Applozic
//
//  Created by Mukesh Thawani on 05/06/18.
//  Copyright © 2018 applozic Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ALApplicationInfo : NSObject

- (BOOL)isChatSuspended;
- (BOOL)showPoweredByMessage;

@end
